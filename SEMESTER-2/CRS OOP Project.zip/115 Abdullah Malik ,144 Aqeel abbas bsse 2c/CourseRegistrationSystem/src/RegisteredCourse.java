public class RegisteredCourse extends Course {
    private double creditHours;

    public RegisteredCourse(String id, String name, String instructor, double creditHours) {
        super(id, name, instructor);
        this.creditHours = creditHours;
    }    
    
    public double getCreditHours() {
        return creditHours;
    }

    @Override
    public void showCourseDetails() {
        System.out.println("Course ID: " + getId() + ", Course Name: " + getName() + ", Instructor: " + getInstructor() + ", Credit Hours: " + creditHours);
    }
}
