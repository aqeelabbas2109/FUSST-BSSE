public class CourseNotFound extends Exception {

    public CourseNotFound(String message) {
        super(message);
    }
}
