public class Student {
    private String name;
    private String rollNo;
    private RegisteredCourse[] registeredCourses;
    private int numRegisteredCourses;

    public Student(String name, String rollNo) {
        this.name = name;
        this.rollNo = rollNo;
        this.registeredCourses = new RegisteredCourse[10];
        this.numRegisteredCourses = 0;
    }

    public Student(String name, String rollNo, RegisteredCourse[] registeredCourses, int numRegisteredCourses) {
        this.name = name;
        this.rollNo = rollNo;
        this.registeredCourses = registeredCourses;
        this.numRegisteredCourses = numRegisteredCourses;
    }

    public void addRegisteredCourse(RegisteredCourse r) {
        if (numRegisteredCourses < 10) {
            registeredCourses[numRegisteredCourses] = r;
            numRegisteredCourses++;
        } else {
            System.out.println("Maximum course limit reached.");
        }
    }

    public String getName() {
        return name;
    }

    public String getRollNo() {
        return rollNo;
    }

    public RegisteredCourse[] getRegisteredCourses() {
        return registeredCourses;
    }

    public int getNumRegisteredCourses() {
        return numRegisteredCourses;
    }

    @Override
    public String toString() {
        return "name= " + name + ", rollNo= " + rollNo+ ", numRegisteredCourses= " + numRegisteredCourses;
    }
}
