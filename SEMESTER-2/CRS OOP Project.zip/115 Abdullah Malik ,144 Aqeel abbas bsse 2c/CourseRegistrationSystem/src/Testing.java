import java.util.Scanner;

public class Testing {

    public static void main(String[] args) {
        RegistrationSystem crs = new RegistrationSystem();
        Scanner input = new Scanner(System.in);
        int choice;
        while (true) {
            System.out.println("\n1. Add Course\n2. Register Student\n3. Show All Courses\n4. Show All Students\n5. Save Student Records to File\n6. Load Previously Saved Records\n7. Exit\nEnter choice: ");
            choice = input.nextInt();
            input.nextLine(); // consume newline character
            switch (choice) {
                case 1:
                    crs.addCourseDetails();
                    break;
                case 2:
                    crs.registerStudentDetails();
                    break;
                case 3:
                    crs.showCourses();
                    break;
                case 4:
                    crs.showStudents();
                    break;
                case 5:
                    crs.saveStudentRecordsToFile();
                    break;
                case 6:
                    crs.loadSavedRecords();
                    break;
                case 7:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid choice, try again.");
            }
        }
    }
}
