public interface Cms {
    public void addCourse(RegisteredCourse r);
    public void registerStudent(Student s);
    public void showCourses();
    public void showStudents();
}
