import java.io.File;
import java.io.FileNotFoundException;
import java.util.Formatter;
import java.util.InputMismatchException;
import java.util.Scanner;

public class RegistrationSystem implements Cms {

    private RegisteredCourse[] registeredCourses;
    private Student[] students;
    private int totalCourses;
    private int totalStudents;

    public RegistrationSystem() {
        this.registeredCourses = new RegisteredCourse[50];
        this.students = new Student[100];
        this.totalCourses = 0;
        this.totalStudents = 0;
    }

    @Override
    public void addCourse(RegisteredCourse r) {
        try {
            if (totalCourses < 50) {
                registeredCourses[totalCourses] = r;
                totalCourses++;
            } else {
                System.out.println("Maximum course limit reached.");
            }
        } catch (Exception e) {
            System.out.println("Error adding course: " + e.getMessage());
        }
    }

    @Override
    public void registerStudent(Student s) {
        try {
            if (totalStudents < 100) {
                students[totalStudents] = s;
                totalStudents++;
            } else {
                System.out.println("Maximum student limit reached.");
            }
        } catch (Exception e) {
            System.out.println("Error registering student: " + e.getMessage());
        }
    }

    @Override
    public void showCourses() {
        try {
            if (totalCourses == 0) {
                throw new CourseNotFound("No courses available. Please add courses.");
            } else {
                for (int i = 0; i < totalCourses; i++) {
                    registeredCourses[i].showCourseDetails();
                }
            }
        } catch (CourseNotFound e) {
            System.out.println(e.getMessage());
        }
    }


    @Override
    public void showStudents() {
        try {
            if (totalStudents == 0) {
                throw new StudentNotFound("No students registered. Please register students");
            } else {
                for (int i = 0; i < totalStudents; i++) {
                    String reg_courses = "";
                    for (int j = 0; j < students[i].getNumRegisteredCourses(); j++) {
                        reg_courses = reg_courses + students[i].getRegisteredCourses()[j].getName();
                        if (j < students[i].getNumRegisteredCourses() - 1) {
                            reg_courses += ", ";
                        }
                    }
                    System.out.println(students[i].toString() + ", registeredCourses= " + reg_courses);
                    System.out.println("-----------------------------");
                }
            }
        } catch (StudentNotFound e) {
            System.out.println(e.getMessage());
        }
    }

    public void addCourseDetails() {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter course ID: ");
        String id = input.nextLine();
        System.out.println("Enter course name: ");
        String name = input.nextLine();
        System.out.println("Enter teacher name: ");
        String teacherName = input.nextLine();
        System.out.println("Enter Credit Hours: ");
        try {
            double creditHours = input.nextDouble();
            input.nextLine(); // consume newline character
            System.out.println("-----------------------------");
            addCourse(new RegisteredCourse(id, name, teacherName, creditHours));
        } catch (InputMismatchException e) {
            System.out.println("Invalid input for credit hours. Please enter a valid number.");
            input.nextLine(); // consume newline character
            addCourseDetails(); // calling the method again to retry
        }
    }

    public void registerStudentDetails() {
        Scanner input = new Scanner(System.in);
        System.out.println("Enter registration number: ");
        String regNo = input.nextLine();
        System.out.println("Enter student name: ");
        String studentName = input.nextLine();
        Student student = new Student(studentName, regNo);
        System.out.println("Enter number of courses to register (max 10):");
        try {
            int numCourses = input.nextInt();
            input.nextLine(); // consume newline character
            boolean allCoursesFound = true;
            for (int i = 0; i < numCourses; i++) {
                System.out.println("Enter course name to register: ");
                String courseName = input.nextLine();
                boolean courseFound = false;
                for (int j = 0; j < totalCourses; j++) {
                    if (registeredCourses[j].getName().equals(courseName)) {
                        student.addRegisteredCourse(registeredCourses[j]);
                        courseFound = true;
                        break;
                    }
                }
                if (!courseFound) {
                    System.out.println("Course not found: " + courseName);
                    allCoursesFound = false;
                    System.out.println("-----------------------------");
                }
            }
            
            if (allCoursesFound) {
                registerStudent(student);
                System.out.println("Student registered successfully.");
                System.out.println("-----------------------------");
            } else {
                System.out.println("Student registration failed. Some courses were not found.");
                System.out.println("-----------------------------");
            }
        } catch (InputMismatchException e) {
            System.out.println("Invalid input for number of courses. Please enter a valid number.");
            input.nextLine(); // consume newline character
            registerStudentDetails(); // call the method again to retry
        }
    }

    public void saveStudentRecordsToFile() {
        try (Formatter fw = new Formatter("D:\\student_records.txt")) {
            for (int i = 0; i < totalStudents; i++) {
                fw.format("%s %s %d ", students[i].getName(), students[i].getRollNo(), students[i].getNumRegisteredCourses());
                for (int j = 0; j < students[i].getNumRegisteredCourses(); j++) {
                    fw.format("%s ", students[i].getRegisteredCourses()[j].getName());
                }
                fw.format("%n");
            }
            System.out.println("Student records saved to file successfully.");
        } catch (FileNotFoundException e) {
            System.out.println("Error: File not found.");
        }
    }

    public void loadSavedRecords() {
        try {
            Scanner input = new Scanner(new File("D:\\student_records.txt"));
            while (input.hasNext()) {
                String name = input.next();
                String rollNo = input.next();
                int numCourses = input.nextInt();
                input.nextLine(); // Consume remaining line
                System.out.println("Name: " + name + ", Roll No: " + rollNo + ", Number of Courses Registered: " + numCourses);
                System.out.println("-----------------------------");
            }
        } catch (FileNotFoundException e) {
            System.out.println("Error loading saved records: File not found.");
        }
    }

}
