
import java.util.ArrayList;
import java.util.List;

public class StudentBinaryTree {
    private class Node {
        Student student;
        Node left, right;

        Node(Student student) {
            this.student = student;
            this.left = null;
            this.right = null;
        }
    }

    private Node root;

    public void addStudent(Student student) {
        root = addRecursive(root, student);
    }

    private Node addRecursive(Node current, Student student) {
        if (current == null) {
            return new Node(student);
        }
        if (student.getRollNo().compareTo(current.student.getRollNo()) < 0) {
            current.left = addRecursive(current.left, student);
        } else if (student.getRollNo().compareTo(current.student.getRollNo()) > 0) {
            current.right = addRecursive(current.right, student);
        }
        return current;
    }

    public Student searchByRollNo(String rollNo) {
        return searchRecursive(root, rollNo);
    }

    private Student searchRecursive(Node current, String rollNo) {
        if (current == null) {
            return null;
        }
        if (rollNo.equals(current.student.getRollNo())) {
            return current.student;
        }
        return rollNo.compareTo(current.student.getRollNo()) < 0
            ? searchRecursive(current.left, rollNo)
            : searchRecursive(current.right, rollNo);
    }

    public boolean deleteStudent(String rollNo) {
        root = deleteRecursive(root, rollNo);
        return root != null; // Returns true if the root is not null, meaning deletion was successful
    }

    private Node deleteRecursive(Node current, String rollNo) {
        if (current == null) {
            return null;
        }
        if (rollNo.equals(current.student.getRollNo())) {
            if (current.left == null && current.right == null) {
                return null;
            }
            if (current.left == null) {
                return current.right;
            }
            if (current.right == null) {
                return current.left;
            }
            Student smallest = findSmallest(current.right);
            current.student = smallest;
            current.right = deleteRecursive(current.right, smallest.getRollNo());
            return current;
        }
        if (rollNo.compareTo(current.student.getRollNo()) < 0) {
            current.left = deleteRecursive(current.left, rollNo);
        } else {
            current.right = deleteRecursive(current.right, rollNo);
        }
        return current;
    }

    private Student findSmallest(Node root) {
        return root.left == null ? root.student : findSmallest(root.left);
    }

    public Student[] getAllStudents() {
        List<Student> students = new ArrayList<>();
        inOrderTraversal(root, students);
        return students.toArray(new Student[0]);
    }

    private void inOrderTraversal(Node node, List<Student> list) {
        if (node != null) {
            inOrderTraversal(node.left, list);
            list.add(node.student);
            inOrderTraversal(node.right, list);
        }
    }
}
