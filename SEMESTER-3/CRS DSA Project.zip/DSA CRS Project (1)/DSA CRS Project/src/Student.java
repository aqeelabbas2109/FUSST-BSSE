public class Student {
    private String name;
    private String rollNo;
    private Course[] registeredCourses;
    private int numRegisteredCourses;

    public Student(String name, String rollNo) {
        this.name = name;
        this.rollNo = rollNo;
        this.registeredCourses = new Course[10];
        this.numRegisteredCourses = 0;
    }

    // Method to add a course to the student's registered courses
    public void addCourse(Course course) {
        if (numRegisteredCourses < 10) {
            registeredCourses[numRegisteredCourses++] = course;
        } else {
            System.out.println("Maximum course limit reached for student " + name + ".");
        }
    }

    // Getter methods
    public String getName() {
        return name;
    }

    public String getRollNo() {
        return rollNo;
    }

    public int getNumRegisteredCourses() {
        return numRegisteredCourses;
    }

    public Course[] getRegisteredCourses() {
        return registeredCourses;
    }

    // Setter methods
    public void setName(String name) {
        this.name = name;
    }

    public void setRollNo(String rollNo) {
        this.rollNo = rollNo;
    }

    // toString method for display
    @Override
    public String toString() {
        return "Student Name: " + name + ", Roll No: " + rollNo + ", Registered Courses: " + numRegisteredCourses;
    }
}
