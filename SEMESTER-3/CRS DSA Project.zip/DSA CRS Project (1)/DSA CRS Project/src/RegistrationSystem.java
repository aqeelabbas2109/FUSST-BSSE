import java.io.*;

public class RegistrationSystem {
    private CourseBinaryTree courseTree;
    private CourseLinkedList courseList;
    private StudentBinaryTree studentTree;
    private StudentLinkedList studentList;

    public RegistrationSystem() {
        courseTree = new CourseBinaryTree();
        courseList = new CourseLinkedList();
        studentTree = new StudentBinaryTree();
        studentList = new StudentLinkedList();
        loadCoursesFromFile();
        loadStudentsFromFile();
    }

    // Add a course to both structures
    public void addCourse(Course course) {
        courseTree.addCourse(course);
        courseList.addCourse(course);
        saveCoursesToFile();
    }

    // Register a student in both structures
    public void registerStudent(Student student) {
        studentTree.addStudent(student);
        studentList.addStudent(student);
        saveStudentsToFile();
    }

    // Search for a course in the tree (preferred) or list as a fallback
    public Course searchCourseById(String id) {
        Course course = courseTree.searchById(id);
        if (course == null) {
            course = courseList.searchById(id);
        }
        return course;
    }

    // Search for a student in the tree (preferred) or list as a fallback
    public Student searchStudentByRollNo(String rollNo) {
        Student student = studentTree.searchByRollNo(rollNo);
        if (student == null) {
            student = studentList.searchByRollNo(rollNo);
        }
        return student;
    }

    // Delete a course from both structures
    public boolean deleteCourseById(String id) {
        boolean deletedFromTree = courseTree.deleteCourse(id);
        boolean deletedFromList = courseList.removeCourseById(id);
        if (deletedFromTree || deletedFromList) {
            saveCoursesToFile();
        }
        return deletedFromTree || deletedFromList;
    }

    // Delete a student from both structures
    public boolean deleteStudentByRollNo(String rollNo) {
        boolean deletedFromTree = studentTree.deleteStudent(rollNo);
        boolean deletedFromList = studentList.removeStudentByRollNo(rollNo);
        if (deletedFromTree || deletedFromList) {
            saveStudentsToFile();
        }
        return deletedFromTree || deletedFromList;
    }

    // Retrieve all courses (from linked list for GUI)
    public Course[] getAllCourses() {
        return courseList.getAllCourses(); // LinkedList is used for display purposes
    }

    // Retrieve all students (from linked list for GUI)
    public Student[] getAllStudents() {
        return studentList.getAllStudents(); // LinkedList is used for display purposes
    }



    // Method to save courses to a file
public void saveCoursesToFile() {
    try (BufferedWriter writer = new BufferedWriter(new FileWriter("courses.txt"))) {
        Course[] allCourses = courseList.getAllCourses(); // Use courseList here
        for (Course course : allCourses) {
            writer.write(course.getId() + "," + course.getName() + "," + course.getInstructor());
            writer.newLine();
        }
    } catch (IOException e) {
        System.out.println("Error saving courses: " + e.getMessage());
    }
}


public void loadCoursesFromFile() {
    try (BufferedReader reader = new BufferedReader(new FileReader("courses.txt"))) {
        String line;
        while ((line = reader.readLine()) != null) {
            String[] data = line.split(",");
            if (data.length == 3) {
                Course course = new Course(data[0], data[1], data[2]);
                courseTree.addCourse(course);  // Add to tree
                courseList.addCourse(course); // Add to linked list
            }
        }
    } catch (IOException e) {
        // File might not exist on the first run; it's okay
        System.out.println("Error loading courses: " + e.getMessage());
    }
}



    // Method to save students to a file
public void saveStudentsToFile() {
    try (BufferedWriter writer = new BufferedWriter(new FileWriter("students.txt"))) {
        Student[] allStudents = studentList.getAllStudents(); // Use studentList
        for (Student student : allStudents) {
            writer.write(student.getRollNo() + "," + student.getName());
            writer.newLine();

            // Save registered courses for each student
            writer.write(String.valueOf(student.getNumRegisteredCourses()));
            writer.newLine();
            for (int i = 0; i < student.getNumRegisteredCourses(); i++) {
                Course course = student.getRegisteredCourses()[i];
                writer.write(course.getId() + "," + course.getName() + "," + course.getInstructor());
                writer.newLine();
            }
        }
    } catch (IOException e) {
        System.out.println("Error saving students: " + e.getMessage());
    }
}


    // Method to load students from a file
public void loadStudentsFromFile() {
    try (BufferedReader reader = new BufferedReader(new FileReader("students.txt"))) {
        String line;
        while ((line = reader.readLine()) != null) {
            String[] data = line.split(",");
            if (data.length == 2) {
                Student student = new Student(data[1], data[0]); // Use correct arguments (name, rollNo)
                studentTree.addStudent(student);  // Add to tree
                studentList.addStudent(student); // Add to linked list

                // Read the number of registered courses
                int numCourses = Integer.parseInt(reader.readLine());
                for (int i = 0; i < numCourses; i++) {
                    String courseLine = reader.readLine();
                    String[] courseData = courseLine.split(",");
                    if (courseData.length == 3) {
                        Course course = new Course(courseData[0], courseData[1], courseData[2]);
                        student.addCourse(course);
                    }
                }
            }
        }
    } catch (IOException e) {
        // File might not exist on the first run; it's okay
        System.out.println("Error loading students: " + e.getMessage());
    }
}


}
