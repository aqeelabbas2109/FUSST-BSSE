public class Heap {
    // Method to heapify a subtree rooted at index i
    public void max_Heapify(int[] arr, int n, int i) {
        int largest = i;
        int left = 2 * i + 1;
        int right = 2 * i + 2;

        if (left < n && arr[left] > arr[largest]) {
            largest = left;
        }

        if (right < n && arr[right] > arr[largest]) {
            largest = right;
        }

        if (largest != i) {
            // Swap and heapify affected subtree
            int swap = arr[i];
            arr[i] = arr[largest];
            arr[largest] = swap;

            max_Heapify(arr, n, largest);
        }
    }

    // Method to build the max heap
    public void build_maxheap(int[] arr) {
        int n = arr.length;
        int startIdx = (n / 2) - 1;

        for (int i = startIdx; i >= 0; i--) {
            max_Heapify(arr, n, i);
        }
    }

    // Heap sort method
    public void heapSort(int[] arr) {
        build_maxheap(arr);
        for (int i = arr.length - 1; i > 0; i--) {
            // Swap root (largest element) with the last element
            int temp = arr[0];
            arr[0] = arr[i];
            arr[i] = temp;

            // Heapify the reduced heap
            max_Heapify(arr, i, 0);
        }
    }

    // Utility method to print the heap
    public void printArray(int[] arr) {
        for (int value : arr) {
            System.out.print(value + " ");
        }
        System.out.println();
    }
}
