public class StudentLinkedList {
    private class Node {
        Student student;
        Node next;

        Node(Student student) {
            this.student = student;
            this.next = null;
        }
    }

    private Node head;

    public StudentLinkedList() {
        head = null;
    }

    public boolean isEmpty() {
        return head == null;
    }

    public void addStudent(Student student) {
        if (isEmpty()) {
            head = new Node(student);
        } else {
            addStudentRecursive(head, student);
        }
    }

    private void addStudentRecursive(Node current, Student student) {
        if (current.next == null) {
            current.next = new Node(student);
        } else {
            addStudentRecursive(current.next, student);
        }
    }

    public boolean removeStudentByRollNo(String rollNo) {
        return removeStudentByRollNoRecursive(head, null, rollNo);
    }

    private boolean removeStudentByRollNoRecursive(Node current, Node prev, String rollNo) {
        if (current == null) return false; // Student not found
        if (current.student.getRollNo().equals(rollNo)) {
            if (prev == null) {
                head = current.next; // Removing head node
            } else {
                prev.next = current.next;
            }
            return true;
        }
        return removeStudentByRollNoRecursive(current.next, current, rollNo);
    }

    public Student searchByRollNo(String rollNo) {
        return searchByRollNoRecursive(head, rollNo);
    }

    private Student searchByRollNoRecursive(Node current, String rollNo) {
        if (current == null) return null; // Student not found
        if (current.student.getRollNo().equals(rollNo)) return current.student;
        return searchByRollNoRecursive(current.next, rollNo);
    }

    public Student[] getAllStudents() {
        int count = getAllStudentsCountRecursive(head);
        Student[] students = new Student[count];
        getAllStudentsRecursive(head, students, 0);
        return students;
    }

    private int getAllStudentsCountRecursive(Node current) {
        if (current == null) return 0;
        return 1 + getAllStudentsCountRecursive(current.next);
    }

    private void getAllStudentsRecursive(Node current, Student[] students, int index) {
        if (current == null) return;
        students[index] = current.student;
        getAllStudentsRecursive(current.next, students, index + 1);
    }
}
