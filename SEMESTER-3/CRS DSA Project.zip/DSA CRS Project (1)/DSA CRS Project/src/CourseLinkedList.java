public class CourseLinkedList {
    private class Node {
        Course course;
        Node next;

        Node(Course course) {
            this.course = course;
            this.next = null;
        }
    }

    private Node head;

    public CourseLinkedList() {
        head = null;
    }

    public boolean isEmpty() {
        return head == null;
    }

    public void addCourse(Course course) {
        Node newNode = new Node(course);
        if (isEmpty()) {
            head = newNode;
        } else {
            addCourseRecursive(head, newNode);
        }
    }

    private void addCourseRecursive(Node current, Node newNode) {
        if (current.next == null) {
            current.next = newNode;
        } else {
            addCourseRecursive(current.next, newNode);
        }
    }

    public boolean removeCourseById(String id) {
        return removeCourseByIdRecursive(head, null, id);
    }

    private boolean removeCourseByIdRecursive(Node current, Node prev, String id) {
        if (current == null) return false; // Course not found
        if (current.course.getId().equals(id)) {
            if (prev == null) {
                head = current.next; // Removing head node
            } else {
                prev.next = current.next;
            }
            return true;
        }
        return removeCourseByIdRecursive(current.next, current, id);
    }

    public Course searchById(String id) {
        return searchByIdRecursive(head, id);
    }

    private Course searchByIdRecursive(Node current, String id) {
        if (current == null) return null; // Course not found
        if (current.course.getId().equals(id)) return current.course;
        return searchByIdRecursive(current.next, id);
    }

    public Course[] getAllCourses() {
        int count = getAllCoursesCountRecursive(head);
        Course[] courses = new Course[count];
        getAllCoursesRecursive(head, courses, 0);
        return courses;
    }

    private int getAllCoursesCountRecursive(Node current) {
        if (current == null) return 0;
        return 1 + getAllCoursesCountRecursive(current.next);
    }

    private void getAllCoursesRecursive(Node current, Course[] courses, int index) {
        if (current == null) return;
        courses[index] = current.course;
        getAllCoursesRecursive(current.next, courses, index + 1);
    }
}
