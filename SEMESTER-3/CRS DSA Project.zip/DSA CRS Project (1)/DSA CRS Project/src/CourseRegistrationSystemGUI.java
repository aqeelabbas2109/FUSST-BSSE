import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.regex.*;

public class CourseRegistrationSystemGUI extends JFrame implements ActionListener {
    private RegistrationSystem crs = new RegistrationSystem();
    private JTextArea displayArea = new JTextArea();
    private JPanel mainPanel, buttonPanel;
    private JButton[] buttons;
    private JButton logoutButton;
    private String[] buttonLabels = {
        "Add Course", "Register Student", "Assign Course to Student",
        "Edit Course", "Edit Student", "Delete Course",
        "Delete Student", "Show All Courses", "Show All Students",
        "Search Course by ID"
    };

    public CourseRegistrationSystemGUI() {
        // Initiate Login
        boolean loginSuccess = showLoginDialog();
        if (!loginSuccess) {
            System.exit(0);
        }

        setTitle("Course Registration System");
        setSize(950, 650); // Increased size to accommodate longer button texts
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setIconImage(loadImage("/images/logo.png").getImage());

        mainPanel = new JPanel(new BorderLayout());
        displayArea.setEditable(false);
        displayArea.setFont(new Font("Consolas", Font.BOLD, 16)); // Set default font to bold and large

        JPanel headerPanel = createHeaderPanel();
        JPanel contentPanel = createContentPanel();

        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(contentPanel, BorderLayout.CENTER);

        add(mainPanel);
        setVisible(true);
    }

    private boolean showLoginDialog() {
        // Create a custom JDialog for the login window
        JDialog loginDialog = new JDialog(this, "Login", true);
        loginDialog.setSize(450, 300);
        loginDialog.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
        loginDialog.setLocationRelativeTo(null);

        // Main panel with gradient background
        JPanel panel = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // Draw gradient background
                Graphics2D g2d = (Graphics2D) g;
                Color color1 = new Color(0, 51, 102); // Dark blue
                Color color2 = new Color(0, 153, 255); // Lighter blue
                GradientPaint gp = new GradientPaint(0, 0, color1, getWidth(), getHeight(), color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };

        GridBagConstraints gbc = new GridBagConstraints();

        // Load the logo image
        ImageIcon logoIcon = loadImage("/images/login.png");
        JLabel logoLabel = new JLabel();
        Image logoImg = logoIcon.getImage().getScaledInstance(80, 80, Image.SCALE_SMOOTH);
        logoLabel.setIcon(new ImageIcon(logoImg));

        // Username and Password labels and fields
        JLabel userLabel = new JLabel("Username:");
        JLabel passLabel = new JLabel("Password:");
        JTextField userField = new JTextField(15);
        JPasswordField passField = new JPasswordField(15);

        // Set text fields to bold
        userField.setFont(new Font("Segoe UI", Font.BOLD, 14));
        passField.setFont(new Font("Segoe UI", Font.BOLD, 14));

        // Set label fonts and colors
        userLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        passLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        userLabel.setForeground(Color.WHITE);
        passLabel.setForeground(Color.WHITE);

        // Show/Hide Password button
        JButton showHideButton = new JButton("Show");
        showHideButton.setFocusPainted(false);
        showHideButton.setFont(new Font("Segoe UI", Font.PLAIN, 12));

        // Add action listener to toggle password visibility
        showHideButton.addActionListener(e -> {
            if ("Show".equals(showHideButton.getText())) {
                passField.setEchoChar((char) 0); // Show password
                showHideButton.setText("Hide");
            } else {
                passField.setEchoChar('•'); // Hide password
                showHideButton.setText("Show");
            }
        });

        // Prepare layout
        gbc.insets = new Insets(10, 10, 5, 10);
        gbc.anchor = GridBagConstraints.WEST;

        // Add logo to the panel
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridheight = 3;
        gbc.gridwidth = 1;
        panel.add(logoLabel, gbc);

        gbc.gridheight = 1;

        // Add Username label and field
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.gridwidth = 1;
        panel.add(userLabel, gbc);

        gbc.gridx = 2;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        panel.add(userField, gbc);

        // Add Password label and field
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        gbc.fill = GridBagConstraints.NONE;
        panel.add(passLabel, gbc);

        gbc.gridx = 2;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        panel.add(passField, gbc);

        // Add Show/Hide Password button below the password field, aligned right
        gbc.gridx = 2;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.EAST;
        gbc.fill = GridBagConstraints.NONE;
        showHideButton.setPreferredSize(new Dimension(80, 25));
        panel.add(showHideButton, gbc);

        // Login button
        JButton loginButton = new JButton("Login");
        loginButton.setBackground(new Color(70, 130, 180));
        loginButton.setForeground(Color.WHITE);
        loginButton.setFocusPainted(false);
        loginButton.setFont(new Font("Segoe UI", Font.BOLD, 14));
        
        gbc.gridx = 2;
        gbc.gridy = 3;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(15, 10, 10, 10);
        panel.add(loginButton, gbc);

        loginDialog.add(panel);
        loginDialog.setResizable(false);

        final boolean[] isAuthenticated = {false};

        // Action listener for login button
        loginButton.addActionListener(e -> {
            String username = userField.getText().trim();
            String password = new String(passField.getPassword()).trim();
            if (username.equals("user") && password.equals("Crs@123")) {
                isAuthenticated[0] = true;
                loginDialog.dispose();
            } else {
                JOptionPane.showMessageDialog(loginDialog, "Invalid credentials.", "Login Failed", JOptionPane.ERROR_MESSAGE);
                userField.setText("");
                passField.setText("");
            }
        });

        // Window listener to handle closing of the dialog
        loginDialog.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                loginDialog.dispose();
            }
        });

        loginDialog.setVisible(true);
        return isAuthenticated[0];
    }

    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                Color color1 = new Color(0, 153, 255);
                Color color2 = new Color(0, 51, 102);
                GradientPaint gp = new GradientPaint(0, 0, color1, getWidth(), 0, color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        headerPanel.setLayout(new BorderLayout());

        JLabel logoLabel = new JLabel();
        ImageIcon logoIcon = loadImage("/images/logo.png");
        Image logoImg = logoIcon.getImage().getScaledInstance(150, 100, Image.SCALE_SMOOTH);
        logoLabel.setIcon(new ImageIcon(logoImg));
        logoLabel.setHorizontalAlignment(SwingConstants.CENTER);

        JLabel titleLabel = new JLabel("Course Registration System", SwingConstants.CENTER);
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 24));

        headerPanel.add(logoLabel, BorderLayout.WEST);
        headerPanel.add(titleLabel, BorderLayout.CENTER);
        headerPanel.setPreferredSize(new Dimension(getWidth(), 120));

        return headerPanel;
    }

    private JPanel createContentPanel() {
        JPanel contentPanel = new JPanel(new BorderLayout());
        JPanel centerPanel = new JPanel(new BorderLayout());

        buttonPanel = createButtonPanel();
        JScrollPane scrollPane = new JScrollPane(displayArea);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());

        centerPanel.add(buttonPanel, BorderLayout.WEST);
        centerPanel.add(scrollPane, BorderLayout.CENTER);

        contentPanel.add(centerPanel, BorderLayout.CENTER);

        // Create and add the Logout button at the bottom
        logoutButton = createLogoutButton();
        contentPanel.add(logoutButton, BorderLayout.SOUTH);

        return contentPanel;
    }

    private JPanel createButtonPanel() {
        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10)) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                Color color1 = new Color(255, 255, 255);
                Color color2 = new Color(220, 220, 220);
                GradientPaint gp = new GradientPaint(0, 0, color1, 0, getHeight(), color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        buttons = new JButton[buttonLabels.length];
        for (int i = 0; i < buttonLabels.length; i++) {
            buttons[i] = new JButton("<html><center>" + buttonLabels[i] + "</center></html>");
            buttons[i].setFocusPainted(false);
        buttons[i].setForeground(Color.WHITE); // Sets text color
buttons[i].setBackground(new Color(70, 130, 180)); // Sets background color

            buttons[i].setFont(new Font("Segoe UI", Font.BOLD, 14));
            buttons[i].setCursor(new Cursor(Cursor.HAND_CURSOR));
            buttons[i].addActionListener(this);
            buttons[i].setPreferredSize(new Dimension(180, 50)); // Increased width and height
            panel.add(buttons[i]);
        }
        return panel;
    }

    private JButton createLogoutButton() {
        JButton logoutBtn = new JButton("Logout");
        logoutBtn.setFocusPainted(false);
        logoutBtn.setForeground(Color.WHITE);
        logoutBtn.setBackground(new Color(178, 34, 34)); // Firebrick color
        logoutBtn.setFont(new Font("Segoe UI", Font.BOLD, 16));
        logoutBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        logoutBtn.setPreferredSize(new Dimension(getWidth(), 50));
        logoutBtn.addActionListener(this);

        return logoutBtn;
    }

    // Centralized Action Listener
    @Override
    public void actionPerformed(ActionEvent e) {
        String action = e.getActionCommand();
        switch (action) {
            case "<html><center>Add Course</center></html>": addCourse(); break;
            case "<html><center>Register Student</center></html>": registerStudent(); break;
            case "<html><center>Assign Course to Student</center></html>": assignCourseToStudent(); break;
            case "<html><center>Edit Course</center></html>": editCourse(); break;
            case "<html><center>Edit Student</center></html>": editStudent(); break;
            case "<html><center>Delete Course</center></html>": deleteCourse(); break;
            case "<html><center>Delete Student</center></html>": deleteStudent(); break;
            case "<html><center>Show All Courses</center></html>": showCourses(); break;
            case "<html><center>Show All Students</center></html>": showStudents(); break;
            case "<html><center>Search Course by ID</center></html>": searchCourseById(); break;
            case "Logout": logout(); break;
            default: break;
        }
    }

    // Helper Methods
    private ImageIcon loadImage(String path) {
        try {
            return new ImageIcon(getClass().getResource(path));
        } catch (Exception e) {
            System.out.println("Image not found: " + path);
            return null;
        }
    }

    private void showMessage(String message, String title, int messageType, ImageIcon icon) {
        JOptionPane.showMessageDialog(this, message, title, messageType, icon);
    }

    private void showMessage(String message, String title, int messageType) {
        JOptionPane.showMessageDialog(this, message, title, messageType);
    }

    private String[] getInputFields(String[] labels, String title, ImageIcon icon, String[] defaultValues, String[] patterns, String[] errorMessages) {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        resizeIcon(icon);

        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JTextField[] textFields = new JTextField[labels.length];

        for (int i = 0; i < labels.length; i++) {
            gbc.gridx = 0; gbc.gridy = i; gbc.weightx = 0;
            JLabel label = new JLabel(labels[i]);
            label.setPreferredSize(new Dimension(180, 25));
            panel.add(label, gbc);

            gbc.gridx = 1; gbc.weightx = 1;
            JTextField textField = new JTextField();
            textField.setPreferredSize(new Dimension(200, 25));
            textField.setFont(new Font("Segoe UI", Font.BOLD, 14)); // Set input text bold
            if (defaultValues != null && defaultValues[i] != null) {
                textField.setText(defaultValues[i]);
            }
            panel.add(textField, gbc);
            textFields[i] = textField;
        }

        while (true) {
            int result = JOptionPane.showConfirmDialog(this, panel, title, JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE, icon);
            if (result == JOptionPane.OK_OPTION) {
                String[] inputs = new String[labels.length];
                for (int i = 0; i < labels.length; i++) {
                    inputs[i] = textFields[i].getText().trim();
                }
                if (validateInputs(inputs, patterns, errorMessages, icon)) return inputs;
            } else {
                return null;
            }
        }
    }

    private boolean validateInputs(String[] inputs, String[] patterns, String[] errorMessages, ImageIcon icon) {
        for (int i = 0; i < inputs.length; i++) {
            if (!Pattern.matches(patterns[i], inputs[i])) {
                showMessage(errorMessages[i], "Input Error", JOptionPane.ERROR_MESSAGE, icon);
                return false;
            }
        }
        return true;
    }

    private void resizeIcon(ImageIcon icon) {
        if (icon != null && icon.getIconWidth() > 64) {
            Image img = icon.getImage().getScaledInstance(64, 64, Image.SCALE_SMOOTH);
            icon.setImage(img);
        }
    }

    // Action Methods
    private void addCourse() {
        ImageIcon icon = loadImage("/images/addcourse.png");
        String[] labels = {"Course ID:", "Course Name:", "Instructor Name:"};
        String[] patterns = {"\\d+", ".+", ".+"};
        String[] errorMessages = {
            "Course ID must contain digits only.",
            "Course Name cannot be empty.",
            "Instructor Name cannot be empty."
        };
        String[] inputs = getInputFields(labels, "Add Course", icon, null, patterns, errorMessages);
        if (inputs != null) {
            crs.addCourse(new Course(inputs[0], inputs[1], inputs[2]));
            showMessage("Course added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE, icon);
        }
    }

    private void registerStudent() {
        ImageIcon icon = loadImage("/images/registerstudent.png");
        String[] labels = {"Student Roll Number:", "Student Name:"};
        String[] patterns = {"\\d+", ".+"};
        String[] errorMessages = {
            "Roll Number must contain digits only.",
            "Student Name cannot be empty."
        };
        String[] inputs = getInputFields(labels, "Register Student", icon, null, patterns, errorMessages);
        if (inputs != null) {
            crs.registerStudent(new Student(inputs[1], inputs[0]));
            showMessage("Student registered successfully!", "Success", JOptionPane.INFORMATION_MESSAGE, icon);
        }
    }

    private void assignCourseToStudent() {
        ImageIcon icon = loadImage("/images/assigncourse.png");
        String[] labels = {"Student Roll Number:", "Course ID to Assign:"};
        String[] patterns = {"\\d+", "\\d+"};
        String[] errorMessages = {
            "Roll Number must contain digits only.",
            "Course ID must contain digits only."
        };
        String[] inputs = getInputFields(labels, "Assign Course to Student", icon, null, patterns, errorMessages);
        if (inputs != null) {
            Student student = crs.searchStudentByRollNo(inputs[0]);
            if (student != null) {
                Course course = crs.searchCourseById(inputs[1]);
                if (course != null) {
                    student.addCourse(course);
                    crs.saveStudentsToFile();
                    showMessage("Course assigned successfully!", "Success", JOptionPane.INFORMATION_MESSAGE, icon);
                } else {
                    showMessage("Course not found.", "Error", JOptionPane.ERROR_MESSAGE, icon);
                }
            } else {
                showMessage("Student not found.", "Error", JOptionPane.ERROR_MESSAGE, icon);
            }
        }
    }

    private void showCourses() {
        Course[] courses = crs.getAllCourses();
        if (courses.length == 0) {
            displayArea.setText("No courses available.");
            return;
        }
        sortCourses(courses);
        String result = "Available Courses:\n\n";
        for (int i = 0; i < courses.length; i++) {
            result += "Course ID: " + courses[i].getId() + "\n";
            result += "Name: " + courses[i].getName() + "\n";
            result += "Instructor: " + courses[i].getInstructor() + "\n";
            result += "------------------------------\n";
        }
        displayArea.setText(result);
    }

private void showStudents() {
    Student[] students = crs.getAllStudents();
    if (students.length == 0) {
        displayArea.setText("No students registered.");
        return;
    }

    // Bubble sort to sort students by name
    int n = students.length;
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - 1 - i; j++) {
            if (students[j].getName().compareTo(students[j + 1].getName()) > 0) {
                // Swap students[j] and students[j + 1]
                Student temp = students[j];
                students[j] = students[j + 1];
                students[j + 1] = temp;
            }
        }
    }

    String result = "Registered Students:\n\n";
    for (Student student : students) {
        result += "Student Name: " + student.getName() + "\n";
        result += "Roll No: " + student.getRollNo() + "\n";
        result += "Registered Courses:\n";
        Course[] courses = student.getRegisteredCourses();
        for (int j = 0; j < student.getNumRegisteredCourses(); j++) {
            if (courses[j] != null) {
                result += "    - Course ID: " + courses[j].getId() + ", ";
                result += "Name: " + courses[j].getName() + ", ";
                result += "Instructor: " + courses[j].getInstructor() + "\n";
            }
        }
        result += "-------------------------------------------------------------\n";
    }
    displayArea.setText(result);
}


    private void searchCourseById() {
    ImageIcon icon = loadImage("/images/searchcourse.png");
    String input = (String) JOptionPane.showInputDialog(this, 
        "Enter Course ID to Search:", 
        "Search Course", 
        JOptionPane.PLAIN_MESSAGE, 
        icon, 
        null, 
        ""
    );
    if (input != null && !input.trim().isEmpty()) {
        String courseId = input.trim();
        if (!Pattern.matches("\\d+", courseId)) {
            showMessage("Course ID must contain digits only.", "Input Error", JOptionPane.ERROR_MESSAGE, icon);
            return;
        }

        // Linear search for the course by ID
        Course[] courses = crs.getAllCourses();
        Course course = null;
        for (int i = 0; i < courses.length; i++) {
            if (courses[i].getId().equals(courseId)) {
                course = courses[i];
                break;
            }
        }

        if (course != null) {
            String result = "Course Found:\n\n";
            result += "Course ID: " + course.getId() + "\n";
            result += "Name: " + course.getName() + "\n";
            result += "Instructor: " + course.getInstructor() + "\n";
            displayArea.setText(result);
        } else {
            displayArea.setText("Course not found.");
        }
    }
}


    private void editCourse() {
        ImageIcon icon = loadImage("/images/editcourse.png");
        String input = JOptionPane.showInputDialog(this, "Enter Course ID to Edit:", "Edit Course", JOptionPane.PLAIN_MESSAGE);
        if (input != null && !input.trim().isEmpty()) {
            String courseId = input.trim();
            if (!Pattern.matches("\\d+", courseId)) {
                showMessage("Course ID must contain digits only.", "Input Error", JOptionPane.ERROR_MESSAGE, icon);
                return;
            }
            Course course = crs.searchCourseById(courseId);
            if (course != null) {
                String[] labels = {"Course ID:", "Course Name:", "Instructor Name:"};
                String[] defaultValues = {course.getId(), course.getName(), course.getInstructor()};
                String[] patterns = {"\\d+", ".+", ".+"};
                String[] errorMessages = {
                    "Course ID must contain digits only.",
                    "Course Name cannot be empty.",
                    "Instructor Name cannot be empty."
                };
                String[] inputs = getInputFields(labels, "Edit Course", icon, defaultValues, patterns, errorMessages);
                if (inputs != null) {
                    course.setId(inputs[0]);
                    course.setName(inputs[1]);
                    course.setInstructor(inputs[2]);
                    crs.saveCoursesToFile();
                    showMessage("Course updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE, icon);
                }
            } else {
                showMessage("Course not found.", "Error", JOptionPane.ERROR_MESSAGE, icon);
            }
        }
    }

    private void editStudent() {
        ImageIcon icon = loadImage("/images/editstudent.png");
        String input = JOptionPane.showInputDialog(this, "Enter Student Roll Number to Edit:", "Edit Student", JOptionPane.PLAIN_MESSAGE);
        if (input != null && !input.trim().isEmpty()) {
            String rollNo = input.trim();
            if (!Pattern.matches("\\d+", rollNo)) {
                showMessage("Roll Number must contain digits only.", "Input Error", JOptionPane.ERROR_MESSAGE, icon);
                return;
            }
            Student student = crs.searchStudentByRollNo(rollNo);
            if (student != null) {
                String[] labels = {"Student Roll Number:", "Student Name:"};
                String[] defaultValues = {student.getRollNo(), student.getName()};
                String[] patterns = {"\\d+", ".+"};
                String[] errorMessages = {
                    "Roll Number must contain digits only.",
                    "Student Name cannot be empty."
                };
                String[] inputs = getInputFields(labels, "Edit Student", icon, defaultValues, patterns, errorMessages);
                if (inputs != null) {
                    student.setRollNo(inputs[0]);
                    student.setName(inputs[1]);
                    crs.saveStudentsToFile();
                    showMessage("Student updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE, icon);
                }
            } else {
                showMessage("Student not found.", "Error", JOptionPane.ERROR_MESSAGE, icon);
            }
        }
    }

    private void deleteCourse() {
        ImageIcon icon = loadImage("/images/deletecourse.png");
        String input = JOptionPane.showInputDialog(this, "Enter Course ID to Delete:", "Delete Course", JOptionPane.PLAIN_MESSAGE);
        if (input != null && !input.trim().isEmpty()) {
            String courseId = input.trim();
            if (!Pattern.matches("\\d+", courseId)) {
                showMessage("Course ID must contain digits only.", "Input Error", JOptionPane.ERROR_MESSAGE, icon);
                return;
            }
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this course?", "Confirm Deletion", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE, icon);
            if (confirm == JOptionPane.YES_OPTION) {
                boolean deleted = crs.deleteCourseById(courseId);
                if (deleted) {
                    showMessage("Course deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE, icon);
                } else {
                    showMessage("Course not found.", "Error", JOptionPane.ERROR_MESSAGE, icon);
                }
            }
        }
    }

    private void deleteStudent() {
        ImageIcon icon = loadImage("/images/deletestudent.png");
        String input = JOptionPane.showInputDialog(this, "Enter Student Roll Number to Delete:", "Delete Student", JOptionPane.PLAIN_MESSAGE);
        if (input != null && !input.trim().isEmpty()) {
            String rollNo = input.trim();
            if (!Pattern.matches("\\d+", rollNo)) {
                showMessage("Roll Number must contain digits only.", "Input Error", JOptionPane.ERROR_MESSAGE, icon);
                return;
            }
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this student?", "Confirm Deletion", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE, icon);
            if (confirm == JOptionPane.YES_OPTION) {
                boolean deleted = crs.deleteStudentByRollNo(rollNo);
                if (deleted) {
                    showMessage("Student deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE, icon);
                } else {
                    showMessage("Student not found.", "Error", JOptionPane.ERROR_MESSAGE, icon);
                }
            }
        }
    }

    private void logout() {
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to logout?", "Logout", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            dispose();
            new CourseRegistrationSystemGUI();
        }
    }

//    // Utility Methods
//    private void sortCourses(Course[] courses) {
//        for (int i = 0; i < courses.length - 1; i++) {
//            int minIdx = i;
//            for (int j = i + 1; j < courses.length; j++) {
//                if (courses[j].getName().compareTo(courses[minIdx].getName()) < 0) {
//                    minIdx = j;
//                }
//            }
//            Course temp = courses[minIdx];
//            courses[minIdx] = courses[i];
//            courses[i] = temp;
//        }
//    }

    public void sortCourses(Course[] courses) {
    if (courses == null || courses.length == 0) return;

    // Convert courses array to numeric IDs for sorting
    int[] ids = new int[courses.length];
    for (int i = 0; i < courses.length; i++) {
        int id = 0;
        String courseId = courses[i].getId();
        for (int j = 0; j < courseId.length(); j++) {
            id = id * 10 + (courseId.charAt(j) - '0'); // Manually parse numeric string to integer
        }
        ids[i] = id;
    }

    // Use the Heap class to sort the IDs
    Heap heap = new Heap();
    heap.build_maxheap(ids); // Build the max heap
    heap.heapSort(ids);      // Sort the array using heap sort

    // Reorder the courses based on sorted IDs
    Course[] sortedCourses = new Course[courses.length];
    int index = 0;
    for (int id : ids) {
        for (int i = 0; i < courses.length; i++) {
            int courseId = 0;
            String currentId = courses[i].getId();
            for (int j = 0; j < currentId.length(); j++) {
                courseId = courseId * 10 + (currentId.charAt(j) - '0');
            }
            if (id == courseId) {
                sortedCourses[index++] = courses[i];
                break;
            }
        }
    }

    // Update original courses array
    for (int i = 0; i < courses.length; i++) {
        courses[i] = sortedCourses[i];
    }
}

    public static void main(String[] args) {
        new CourseRegistrationSystemGUI();
    }
}
