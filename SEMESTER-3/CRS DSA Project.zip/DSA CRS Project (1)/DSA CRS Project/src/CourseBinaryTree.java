
import java.util.ArrayList;
import java.util.List;

public class CourseBinaryTree {
    private class Node {
        Course course;
        Node left, right;

        Node(Course course) {
            this.course = course;
            this.left = null;
            this.right = null;
        }
    }

    private Node root;

    public void addCourse(Course course) {
        root = addRecursive(root, course);
    }

    private Node addRecursive(Node current, Course course) {
        if (current == null) {
            return new Node(course);
        }
        if (course.getId().compareTo(current.course.getId()) < 0) {
            current.left = addRecursive(current.left, course);
        } else if (course.getId().compareTo(current.course.getId()) > 0) {
            current.right = addRecursive(current.right, course);
        }
        return current;
    }

    public Course searchById(String id) {
        return searchRecursive(root, id);
    }

    private Course searchRecursive(Node current, String id) {
        if (current == null) {
            return null;
        }
        if (id.equals(current.course.getId())) {
            return current.course;
        }
        return id.compareTo(current.course.getId()) < 0
            ? searchRecursive(current.left, id)
            : searchRecursive(current.right, id);
    }

    public boolean deleteCourse(String id) {
        return deleteRecursive(root, id) != null;
    }

    private Node deleteRecursive(Node current, String id) {
        if (current == null) {
            return null;
        }
        if (id.equals(current.course.getId())) {
            if (current.left == null && current.right == null) {
                return null;
            }
            if (current.left == null) {
                return current.right;
            }
            if (current.right == null) {
                return current.left;
            }
            Course smallest = findSmallest(current.right);
            current.course = smallest;
            current.right = deleteRecursive(current.right, smallest.getId());
            return current;
        }
        if (id.compareTo(current.course.getId()) < 0) {
            current.left = deleteRecursive(current.left, id);
            return current;
        }
        current.right = deleteRecursive(current.right, id);
        return current;
    }

    private Course findSmallest(Node root) {
        return root.left == null ? root.course : findSmallest(root.left);
    }

    public Course[] getAllCourses() {
        List<Course> courses = new ArrayList<>();
        inOrderTraversal(root, courses);
        return courses.toArray(new Course[0]);
    }

    private void inOrderTraversal(Node node, List<Course> list) {
        if (node != null) {
            inOrderTraversal(node.left, list);
            list.add(node.course);
            inOrderTraversal(node.right, list);
        }
    }
}
